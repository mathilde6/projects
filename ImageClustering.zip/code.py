#!/usr/bin/env python
# coding: utf-8

import os, codecs
import shutil
import cv2
import numpy as np
from sklearn.cluster import KMeans

from sklearn.metrics import silhouette_score


"""
 load single image
"""
def getImgs(file):
    
    img = cv2.imread(file)

    nhist = cv2.calcHist([img], [0,1], None, [64,64], [0.0, 255.0,0.0, 255.0])
    # img = cv2.resize(img, (50, 50), interpolation=cv2.INTER_CUBIC)
    # nhist = cv2.calcHist([img], [0, 1, 2], None, [64, 64, 64],
    #                      [0, 256, 0, 256, 0, 256])
    nhist = cv2.normalize(nhist, nhist, 0, 1, cv2.NORM_MINMAX).flatten()
    
    return nhist

"""
Load all images

"""
def getFile(path):
    
    fileNames = []
    
    imgs = []
    
    for a,b,files in os.walk(path):
        
        for file in files:
            
            imgs.append(getImgs(os.sep.join([a,file])))
            
            fileNames.append(file)
            
    return np.array(imgs),fileNames


imgs,fileNames = getFile('../images')


"""
 find the best K
"""
for k in range(2,15,2):

    kmeans = KMeans(n_clusters=k,max_iter=500)
	
    kmeans.fit(imgs)
	
    pre = kmeans.predict(imgs)
	
    value = silhouette_score(imgs,pre)
	
    print(k, value)


"""
 k = 2  is the best

"""

kmeans = KMeans(n_clusters=2)
kmeans.fit(imgs)


preLable = kmeans.predict(imgs) + 1


import pandas as pd
d = pd.Series(preLable)
d.value_counts()


outFile = pd.DataFrame()

fileNames_ = np.array([s.split('.')[0] for s in fileNames ])

for l in set(preLable):

    index  = np.where(preLable == l)
	
    names = fileNames_[index]
	
    names = pd.Series(names,name = 'Cluster '+str(l))
	
    outFile = pd.concat([outFile,names],axis = 1)


outFile.to_excel('sub_v2.xls',encoding = 'utf-8',index = None )


outFile.head()

