import tensorflow as tf
from statsmodels.tsa.seasonal import seasonal_decompose
import warnings
import statsmodels as sm
from statsmodels.graphics.tsaplots import plot_acf, plot_pacf
from statsmodels.tsa.arima_model import ARIMA
import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import os
from tqdm import tqdm
from statsmodels.graphics.tsaplots import plot_acf
from statsmodels.tsa.stattools import adfuller as ADF
from statsmodels.graphics.tsaplots import plot_pacf
from statsmodels.stats.diagnostic import acorr_ljungbox

def arima_model():
    os.chdir('../data')
    ### Combine the data
    air1 = pd.read_csv('airQuality_201701-201801.csv', engine='python')
    air2 = pd.read_csv('airQuality_201802-201803.csv', engine='python')
    air3 = pd.read_csv('aiqQuality_201804.csv', engine='python')
    air3 = air3.drop('id', axis=1)
    air3.columns = air1.columns

    air = pd.concat([air1, air2, air3])
    air = pd.concat([air1, air2, air3])
    air['utc_time'] = air['utc_time'].astype('datetime64')

    dt = pd.date_range('2018-03-01 00:00:00', '2018-04-30 23:00:00', freq='h')
    dt = pd.DataFrame(dt, columns=['utc_time'])

    station_id = list(set(air['stationId']))

    air = air.sort_values('utc_time').drop(['NO2', 'CO', 'SO2'], axis=1)
    data_air = air[(air['utc_time'] >= '2018-03-01 00:00:00') &
                (air['utc_time'] <= '2018-04-30 23:00:00')]


    k = 0
    for i in station_id:
        if k == 0:
            temp1 = pd.concat(
                [dt, pd.DataFrame([i]*len(dt), columns=['stationId'])], axis=1)
            temp = temp1.copy()
        else:
            temp1 = pd.concat(
                [dt, pd.DataFrame([i]*len(dt), columns=['stationId'])], axis=1)
            temp = pd.concat([temp, temp1])
        k += 1

    data_final = pd.merge(temp, data_air, on=[
                        'utc_time', 'stationId'], how='outer')

    station_data = []
    for i in station_id:
        station_data.append(data_final[data_final['stationId'] == i].sort_values(
            'utc_time').drop_duplicates('utc_time').fillna(method='ffill'))




    # PM2.5
    # prediction_results
    k = 0
    for i in station_id:
        d1 = station_data[k].loc[:, ['utc_time', 'PM2.5']]
        d1.index = d1['utc_time'].astype('datetime64', freq='h')
        d1 = d1.drop('utc_time', axis=1).fillna(method='bfill')

        decomposition = seasonal_decompose(d1, model="additive")
        k += 1
        trend = decomposition.trend
        seasonal = decomposition.seasonal
        residual = decomposition.resid

        model_res = ARIMA(residual.dropna(), (5, 0, 1)).fit()
        res = model_res.forecast(48)[0]
        td = pd.DataFrame(trend.values, index=(trend.index+pd.Timedelta('7D')))
        sn = pd.DataFrame(seasonal.values, index=(
            seasonal.index+pd.Timedelta('7D')))

        aaa = np.squeeze(td[(td.index >= '2018-04-29 00:00:00') & (td.index <= '2018-04-30 23:00:00')].values.T) + \
            np.squeeze(sn[(sn.index >= '2018-04-29 00:00:00') &
                        (sn.index <= '2018-04-30 23:00:00')].values.T)+res

        idx = []
        for j in range(48):
            idx.append(str(i)+'#'+str(j))

        if k == 1:
            p2 = pd.DataFrame(aaa, index=idx, columns=['PM2.5'])
        else:
            p2 = pd.concat([p2, pd.DataFrame(aaa, index=idx, columns=['PM2.5'])])

    # PM10
    # prediction_results
    k = 0
    for i in station_id:
        d1 = station_data[k].loc[:, ['utc_time', 'PM10']]
        d1.index = d1['utc_time'].astype('datetime64', freq='h')
        d1 = d1.drop('utc_time', axis=1).fillna(method='bfill')

        decomposition = seasonal_decompose(d1, model="additive")
        k += 1
        trend = decomposition.trend
        seasonal = decomposition.seasonal
        residual = decomposition.resid

        model_res = ARIMA(residual.dropna(), (5, 0, 1)).fit()
        res = model_res.forecast(48)[0]
        td = pd.DataFrame(trend.values, index=(trend.index+pd.Timedelta('7D')))
        sn = pd.DataFrame(seasonal.values, index=(
            seasonal.index+pd.Timedelta('7D')))
            
        aaa = np.squeeze(td[(td.index >= '2018-04-29 00:00:00') & (td.index <= '2018-04-30 23:00:00')].values.T) + \
            np.squeeze(sn[(sn.index >= '2018-04-29 00:00:00') &
                        (sn.index <= '2018-04-30 23:00:00')].values.T)+res

        idx = []
        for j in range(48):
            idx.append(str(i)+'#'+str(j))

        if k == 1:
            p10 = pd.DataFrame(aaa, index=idx, columns=['PM10'])
        else:
            p10 = pd.concat([p10, pd.DataFrame(aaa, index=idx, columns=['PM10'])])

        # O3
    # prediction_results
    k = 0
    for i in station_id:
        d1 = station_data[k].loc[:, ['utc_time', 'O3']]
        d1.index = d1['utc_time'].astype('datetime64', freq='h')
        d1 = d1.drop('utc_time', axis=1).fillna(method='bfill')

        decomposition = seasonal_decompose(d1, model="additive")
        k += 1
        trend = decomposition.trend
        seasonal = decomposition.seasonal
        residual = decomposition.resid

        model_res = ARIMA(residual.dropna(), (5, 0, 1)).fit()
        res = model_res.forecast(48)[0]
        td = pd.DataFrame(trend.values, index=(trend.index+pd.Timedelta('7D')))
        sn = pd.DataFrame(seasonal.values, index=(
            seasonal.index+pd.Timedelta('7D')))

        aaa = np.squeeze(td[(td.index >= '2018-04-29 00:00:00') & (td.index <= '2018-04-30 23:00:00')].values.T) + \
            np.squeeze(sn[(sn.index >= '2018-04-29 00:00:00') &
                        (sn.index <= '2018-04-30 23:00:00')].values.T)+res

        idx = []
        for j in range(48):
            idx.append(str(i)+'#'+str(j))

        if k == 1:
            O3 = pd.DataFrame(aaa, index=idx, columns=['O3'])
        else:
            O3 = pd.concat([O3, pd.DataFrame(aaa, index=idx, columns=['O3'])])

    # PM10
    # prediction_results
    k = 27
    for i in ['aotizhongxin_aq']:  # station_id:
        d1 = station_data[k].loc[:, ['utc_time', 'PM10']]
        d1.index = d1['utc_time'].astype('datetime64', freq='h')
        d1 = d1.drop('utc_time', axis=1).fillna(method='bfill')
        decomposition = seasonal_decompose(d1, model="additive")
        k += 1
        trend = decomposition.trend
        seasonal = decomposition.seasonal
        residual = decomposition.resid

        model_res = ARIMA(residual.dropna(), (5, 0, 1)).fit()
        res = model_res.forecast(48)[0]
        td = pd.DataFrame(trend.values, index=(trend.index+pd.Timedelta('7D')))
        sn = pd.DataFrame(seasonal.values, index=(
            seasonal.index+pd.Timedelta('7D')))

        plt.figure(figsize=(16, 8))
        plt.grid(True)
        aaa = np.squeeze(td[(td.index >= '2018-04-26 00:00:00') & (td.index <= '2018-04-27 23:00:00')].values.T) + \
            np.squeeze(sn[(sn.index >= '2018-04-29 00:00:00') &
                        (sn.index <= '2018-04-30 23:00:00')].values.T)+res
        plt.plot(pd.date_range('2018-04-29 00:00:00',
                            '2018-04-30 23:00:00', freq='h'), aaa)
        plt.plot_date(d1.index[-48:], d1['PM10'].iloc[-48:].values, '-.')

        idx = []
        for j in range(48):
            idx.append(str(i)+'#'+str(j))

    def smape_loss(y_true, y_pred):
            temp1 = K.abs(y_true - y_pred)
            temp2 = (y_true + y_pred)/2
            return K.mean(temp1/temp2, axis=-1)

    import keras.backend as K
    with tf.Session() as sess:
        print('ARIMA smape: %0.4f' %(sess.run(smape_loss(aaa, d1['PM10'].iloc[-48:].values))))
