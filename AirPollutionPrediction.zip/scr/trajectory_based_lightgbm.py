import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import os
import seaborn as sns
from tqdm import tqdm
import lightgbm as lgb
from sklearn.model_selection import cross_val_score

def trajectory_based_lgb():
    os.chdir(r'../data')
    dd1 = pd.read_csv('./data_inte.csv', engine='python', index_col=0)
    data = pd.read_csv('./data_integration_version2.csv', engine='python', index_col=1).drop('Unnamed: 0', axis=1)
    data['utc_time'] = data['utc_time'].astype('datetime64')
    data['day_of_year'] = data['utc_time'].apply(lambda x: x.dayofyear)
    data['day_of_week'] = data['utc_time'].apply(lambda x: x.dayofweek)
    data['hour_of_day'] = data['utc_time'].apply(lambda x: x.hour)
    data['day_of_quater'] = data['utc_time'].apply(lambda x: x.quarter)

    dd2 = pd.concat([data['utc_time'], dd1], axis=1)
    dd2['utc_time'] = dd2['utc_time'].astype('datetime64')

    #### Attention: time+1h, start: 2017-01-01 14:00(original)
    dd2['utc_time'] = dd2['utc_time'] + pd.Timedelta('1h')

    dd3 = pd.concat([data, dd2.drop('utc_time', axis=1)], axis=1).fillna(0)
    dd3 = dd3.sort_index()

    N = 200000
    lt = 48
    x_tr = dd3.drop(['wind_direction'], axis=1).iloc[:N, 4:]
    x_val = dd3.drop(['wind_direction'], axis=1).iloc[N:N+lt, 4:]
    y_tr = dd3.drop(['wind_direction'], axis=1).iloc[:N, 1:4]
    y_val = dd3.drop(['wind_direction'], axis=1).iloc[N:N+lt, 1:4]

    y_tr_p2 = y_tr['PM2.5']
    y_val_p2 = y_val['PM2.5']

    y_tr_p10 = y_tr['PM10']
    y_val_p10 = y_val['PM10']

    y_tr_o3 = y_tr['O3']
    y_val_o3 = y_val['O3']

    model_p2 = lgb.LGBMRegressor(
        max_depth=6,
        feature_fraction=0.6,
        bagging_frequency=6,
        bagging_seed=42)
    model_p2.fit(x_tr.values, np.log1p(y_tr_p2.values))

    model_p10 = lgb.LGBMRegressor(
        max_depth=6,
        feature_fraction=0.6,
        bagging_frequency=6,
        bagging_seed=42)
    model_p10.fit(x_tr.values, np.log1p(y_tr_p10.values))

    model_o3 = lgb.LGBMRegressor(
        max_depth=6,
        feature_fraction=0.6,
        bagging_frequency=6,
        bagging_seed=42)
    model_o3.fit(x_tr.values, np.log1p(y_tr_o3.values))

    zhi = np.expm1(model_p2.predict(x_val.values))
    zhi = pd.Series(zhi, index=y_val_p2.index)


    def loss_function(original_data, predicted_data):
        '''
        This function is used to compute Symmetric mean absolute percentage error.
        original_data: 
            - Genuine data
            - Format: pd.Series
        predicted_data: 
            - Predicted data
            - Format: pd.Series
        '''
        temp1 = abs(original_data - predicted_data)
        temp2 = (original_data + predicted_data)/2
        return (temp1/temp2).mean()


    ### prediction for each station
    ### wavelet decomposition & non-decomposition

    predict_time = pd.Timestamp('2017-04-25 21:00')
    time_len = 51
    num = pd.Timedelta(str(time_len)+'h')
    x_pre = dd3.loc[(dd3['utc_time'] >= predict_time) & (
        dd3['utc_time'] <= (predict_time+num)), :].iloc[:, :1]

    match_aq_gw = pd.read_csv('mathc_aq_gw.csv', engine='python', index_col=0)
    gw = pd.read_csv('grid_weather_all.csv', engine='python', index_col=0)
    gw['utc_time'] = gw['utc_time'].astype('datetime64')
    x_pre['station_id'] = x_pre.index

    merge1 = pd.merge(match_aq_gw, x_pre, on='station_id')
    merge1.columns = ['station_aq', 'station_id', 'utc_time']
    merge2 = pd.merge(merge1, gw, on=['station_id', 'utc_time']).sort_values(
        ['station_aq', 'utc_time']).drop(['station_id'], axis=1)
    distance_matrix = pd.read_csv(
        'distance_matrix.csv', engine='python', index_col=0)
    time_interval = dd3[(dd3['utc_time'] >= predict_time) &
                        (dd3['utc_time'] <= predict_time+num)]

    ### extract time interval needed prection
    for i in range(time_len):
        if i == 0:
            settings = pd.DataFrame([predict_time+pd.Timedelta(str(i)+'h')]
                                    * 35, index=distance_matrix.index, columns=['utc_time'])
            settings.index.name = 'station_aq'
        else:
            tt = pd.DataFrame([predict_time+pd.Timedelta(str(i)+'h')]
                            * 35, index=distance_matrix.index, columns=['utc_time'])
            settings = pd.concat([settings, tt])

    tt = pd.merge(time_interval, settings, on=[
                'station_aq', 'utc_time'], how='outer')
    tt['station_aq'] = tt.index
    tt.index = range(len(tt))

    ### use the previous values to fill nan
    for i in list(set(distance_matrix.index)):
        tt.update(tt[tt['station_aq'] == i].sort_values(
            'utc_time').fillna(method='ffill'))


    y_true = tt.loc[:, ['utc_time', 'station_aq', 'PM2.5', 'PM10', 'O3']]
    tt = tt[tt['utc_time'] > pd.Timestamp(
        '2017-04-25 23:00:00')].fillna(0).drop(['PM2.5', 'PM10', 'O3'], axis=1)

    record = pd.concat(
        [pd.DataFrame(index=tt.index, columns=['PM2.5', 'PM10', 'O3']), tt], axis=1)

    ### vector matrix
    jw_distance = pd.read_excel(
        'Beijing_AirQuality_Stations_en.xlsx', sheet_name='Sheet2', index_col='Station ID')
    vec_station = pd.DataFrame(index=jw_distance.index, columns=jw_distance.index)
    for i in jw_distance.index:
        for j in jw_distance.index:
            vec_station.loc[i, j] = np.array(
                jw_distance.loc[i, :] - jw_distance.loc[j, :])  # (longitude, latitude)


    ### validation and prediction
    for i in tqdm(range(3, time_len)):
        for j in list(set(distance_matrix.index)):
            idx = (record['utc_time'] == (predict_time +
                                        pd.Timedelta(str(i)+'h'))) & (record['station_aq'] == j)
            val_data = record.loc[idx, x_tr.columns]
            c_PM2 = model_p2.predict(val_data)[0]
            c_PM10 = model_p10.predict(val_data)[0]
            c_O3 = model_o3.predict(val_data)[0]

            record.loc[idx, 'PM2.5'] = c_PM2
            record.loc[idx, 'PM10'] = c_PM10
            record.loc[idx, 'O3'] = c_O3
            if i == time_len-1:  # attention!!!
                continue
            else:
                wind_idx = record.loc[idx, 'wind_direction']
                wind_temp = record.loc[idx, 'wind_speed'].values[0]
                wx = np.cos(wind_idx).values[0]
                wy = -np.sin(wind_idx).values[0]
                for k in list(set(distance_matrix.index)):
                    next_idx = (record['utc_time'] == (
                        predict_time+pd.Timedelta(str(i+1)+'h'))) & (record['station_aq'] == k)

                    vdx, vdy = vec_station.loc[k, j]
                    vd_vtheta = wx*vdx + wy*vdy

                    if k == j:
                        dist = 1
                        vd_vtheta = 1
                        wind_temp = 1
                    else:
                        dist = distance_matrix.loc[j, k]

                    record.loc[next_idx, str(k)+'PM2.5'] = c_PM2 * \
                        wind_temp * vd_vtheta / dist
                    record.loc[next_idx, str(k)+'PM10'] = c_PM10 * \
                        wind_temp * vd_vtheta / dist
                    record.loc[next_idx, str(k)+'O3'] = c_O3 * \
                        wind_temp * vd_vtheta / dist

    aaa = y_true.loc[y_true['station_aq'] == 'aotizhongxin_aq', :].drop_duplicates(
        'utc_time').sort_values('utc_time')['PM10'].iloc[3:]
    aaa.index = range(len(aaa))

    bbb = record.loc[record['station_aq'] == 'aotizhongxin_aq',
                    :].drop_duplicates('utc_time').sort_values('utc_time')['PM10']
    bbb.index = range(len(bbb))

    print ('trajectory_based_lgb smape: %0.4f'  %((abs(aaa - bbb)*2/(aaa+bbb)).sum()/len(aaa)))

