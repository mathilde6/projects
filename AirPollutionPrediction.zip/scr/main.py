from data_integration import data_integration
from arima import arima_model
from LSTM import lstm_model
from trajectory_based_lightgbm import trajectory_based_lgb

def main():
    print('---data integration---')
    data_integration()
    print('---ARIMA model---')
    arima_model()
    print('---LSTM model---')
    lstm_model()
    print('---Trajectory based lightGBM model---')
    trajectory_based_lgb()
    print('Finish!')

main()
