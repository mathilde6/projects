import tensorflow as tf
import keras.backend as K
from keras.layers import BatchNormalization, LSTM
from keras.layers import Dense, Dropout, Flatten
from keras.optimizers import Adam, SGD
from keras.models import Sequential
import keras
import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import os
import seaborn as sns
from tqdm import tqdm

os.chdir('..\data')
def lstm_model():
    data = pd.read_csv('./data_integration_version2.csv',
                    engine='python', index_col=1).drop('Unnamed: 0', axis=1)
                    
    data['utc_time'] = data['utc_time'].astype('datetime64')
    data['day_of_year'] = data['utc_time'].apply(
        lambda x: np.cos(x.dayofyear*2*np.pi/365))
    data['day_of_week'] = data['utc_time'].apply(lambda x: x.dayofweek)
    data['hour_of_day'] = data['utc_time'].apply(lambda x: x.hour)
    data['day_of_quater'] = data['utc_time'].apply(lambda x: x.quarter)

    data['wind_x'] = data['wind_direction'].apply(lambda x: np.cos(x))
    data['wind_y'] = data['wind_direction'].apply(lambda x: -np.sin(x))

    data['station_aq'] = data.index
    data.index = range(len(data))

    data = data.sort_values(['station_aq', 'utc_time'])

    station1_data = data[data['station_aq'] == 'aotizhongxin_aq']

    ### construct time series chunks for LSTM
    time_step = 21
    station1_data_x = station1_data.drop(
        ['utc_time', 'PM2.5', 'PM10', 'O3', 'station_aq'], axis=1)
    station1_data_y = station1_data.loc[:, ['PM2.5', 'PM10', 'O3']]

    station1_data_x = (station1_data_x - station1_data_x.mean()) / \
        station1_data_x.std()
    station1_data_y = np.log1p(station1_data_y)

    rnn_x = []
    rnn_y = []
    for i in range(time_step, len(station1_data)-47):
        rnn_x.append(station1_data_x.iloc[i-time_step:i, :].values.tolist())
        rnn_y.append(station1_data_y.iloc[i:i+48, :].values.tolist())
        

    def smape_loss(y_true, y_pred):
        '''
        This function is used to compute Symmetric mean absolute percentage error.
        original_data: 
            - Genuine data
            - Format: pd.Series
        predicted_data: 
            - Predicted data
            - Format: pd.Series
        '''
        temp1 = K.abs(y_true - y_pred)
        temp2 = (y_true + y_pred)/2
        return K.mean(temp1/temp2, axis=-1)

    def more_large_loss(y_true, y_pred):
        '''
        This function is used to compute Symmetric mean absolute percentage error.
        original_data: 
            - Genuine data
            - Format: pd.Series
        predicted_data: 
            - Predicted data
            - Format: pd.Series
        '''
        return K.mean(K.pow(K.abs(y_true - y_pred), 2), axis=-1)


    class CONFIG():
        '''
        This is the parameters setting
        '''
        # LSTM
        units = 128
        # Dropout
        dropout = 0.5
        ### dense
        predict_num = 48  # PM2.5, PM10, O3


    ### Get architecture parameters
    config = CONFIG()

    ### LSTM Achitecture
    model = Sequential()
    model.add(LSTM(config.units, input_shape=(21, 11)))
    model.add(Dropout(config.dropout))
    model.add(Dense(config.predict_num))
    adm = Adam(lr=0.001, decay=1e-6)
    model.compile(loss=more_large_loss,  # 'mean_squared_error',#smape_loss,
                optimizer=adm)
                

    N = 6000  # separation of training set and test set
    rnn_x = np.array(rnn_x)
    rnn_y = np.array(rnn_y)

    rnn_x_tr = rnn_x[:N]
    rnn_y_tr = rnn_y[:N, :, 0]  # PM2.5
    rnn_x_val = rnn_x[N:]
    rnn_y_val = rnn_y[N:, :, 0]  # PM2.5


    model.fit(rnn_x_tr, rnn_y_tr,
            epochs=10,
            batch_size=200)
    y_plot1 = rnn_y_val[-1]
    y_plot2 = np.squeeze(model.predict(rnn_x_val[-1:]))
    with tf.Session() as sess:
        print('LSTM smape: %0.4f' %(sess.run(smape_loss(np.expm1(y_plot1), np.expm1(y_plot2)))))
