import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import os
import seaborn as sns
from tqdm import tqdm

def data_integration():
    os.chdir(r'../data')
    data = pd.read_csv('./test_data.csv', engine='python', index_col=0)

    location_aq = pd.read_excel('Beijing_AirQuality_Stations_en.xlsx', sheet_name='Sheet2')
    location_aq.columns = ['station_id', 'latitude', 'longitude']

    gw1 = pd.read_csv('gridWeather_201701-201803.csv', engine='python').drop(['longitude', 'latitude'], axis=1)
    gw2 = pd.read_csv('gridWeather_201804.csv', engine='python').drop(['id', 'weather'], axis=1)
    gw3 = pd.read_csv('gridWeather_20180501-20180502.csv', engine='python').drop(['id', 'weather'], axis=1)

    gw1.columns = ['station_id', 'utc_time', 'temperature', 'pressure', 'humidity', 'wind_direction', 'wind_speed']
    gw2.columns = ['station_id', 'utc_time', 'temperature', 'pressure', 'humidity', 'wind_direction', 'wind_speed']
    gw3.columns = ['station_id', 'utc_time', 'temperature', 'pressure', 'humidity', 'wind_direction', 'wind_speed']
    gw = pd.concat([gw1, gw2, gw3])
    location_gw = pd.read_csv('Beijing_grid_weather_station.csv',header=None, engine='python')
    location_gw.columns = ['station_id', 'longitude', 'latitude']
    match_aq_gw = pd.Series(index=location_aq['station_id'])
    for i in range(len(location_aq)):
        temp_dis = np.sqrt(((location_gw[['longitude', 'latitude']] - location_aq.iloc[i, 1:])**2).sum(1))
        match_aq_gw[location_aq['station_id'].iloc[i]] = location_gw.loc[temp_dis.loc[temp_dis==temp_dis.min()].index[0], 'station_id']
    match_aq_gw = pd.concat([pd.Series(match_aq_gw.index, index=match_aq_gw.index), match_aq_gw], axis=1)
    match_aq_gw.index = range(len(match_aq_gw))
    match_aq_gw.columns = ['station_id', 'station_gw']

    ### Integrate the grid weather data and air quality data
    data.columns = ['station_id', 'utc_time', 'PM2.5', 'PM10', 'O3']

    gw.to_csv('grid_weather_all.csv')
    match_aq_gw.to_csv('mathc_aq_gw.csv')
    data_merge_aq_gw_station = pd.merge(data, match_aq_gw, on='station_id')
    data_merge_aq_gw_station.columns =  ['station_aq', 'utc_time', 'PM2.5', 'PM10', 'O3', 'station_id']
    bfinal_data = pd.merge(data_merge_aq_gw_station, gw, on=['station_id', 'utc_time']).drop('station_id', axis=1)

    bfinal_data[bfinal_data['wind_direction'] > 10000] = 0.001

    ### Form Multiindex
    tp_idx = bfinal_data.copy()
    tp_idx['utc_time'] = tp_idx['utc_time'].astype('datetime64')

    tp_idx.index = tp_idx[['utc_time', 'station_aq']]
    tp_idx.index = pd.MultiIndex.from_tuples(tp_idx.index)

    tp_idx = tp_idx.sort_index(level=0)
    tp_idx = tp_idx.drop('station_aq', axis=1)
    bfinal_data.to_csv('./data_integration_version2.csv')
